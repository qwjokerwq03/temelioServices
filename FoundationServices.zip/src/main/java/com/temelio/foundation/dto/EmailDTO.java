package com.temelio.foundation.dto;

import java.util.Date;

import lombok.Data;

@Data
public class EmailDTO {
	
	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public FoundationDTO getFoundationDTO() {
		return foundationDTO;
	}

	public void setFoundationDTO(FoundationDTO foundationDTO) {
		this.foundationDTO = foundationDTO;
	}

	public NonprofitDTO getNonprofitDTO() {
		return nonprofitDTO;
	}

	public void setNonprofitDTO(NonprofitDTO nonprofitDTO) {
		this.nonprofitDTO = nonprofitDTO;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	private Long Id;
	
	private FoundationDTO foundationDTO;
	
	private NonprofitDTO nonprofitDTO;
	
	private Date date; 
	
}
