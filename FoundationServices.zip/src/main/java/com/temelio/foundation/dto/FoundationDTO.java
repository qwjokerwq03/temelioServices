package com.temelio.foundation.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FoundationDTO {
    private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}

