package com.temelio.foundation.dto.mapper;

import org.mapstruct.Mapper;

import com.temelio.foundation.dto.NonprofitDTO;
import com.temelio.foundation.entity.Nonprofit;

@Mapper(componentModel = "spring")
public interface NonprofitMapper {

    Nonprofit nonprofitDTOToNonprofit(NonprofitDTO nonprofitDTO);

    NonprofitDTO nonprofitToNonprofitDTO(Nonprofit nonprofit);
}


