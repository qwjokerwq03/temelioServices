package com.temelio.foundation.dto.mapper;
import org.mapstruct.Mapper;

import com.temelio.foundation.dto.EmailDTO;
import com.temelio.foundation.dto.EmailTemplateDTO;
import com.temelio.foundation.entity.Email;
import com.temelio.foundation.entity.EmailTemplate;

@Mapper(componentModel = "spring")
public interface EmailMapper {
	
	EmailDTO emailToEmailDTO(Email email);
	
	EmailTemplate emailTemplateDTOToEmailTemplate(EmailTemplateDTO emailTemplateDTO);
	
	EmailTemplateDTO emailTemplateToEmailTemplateDTO(EmailTemplate emailTemplate);
}
