package com.temelio.foundation.dto.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.temelio.foundation.dto.FoundationDTO;
import com.temelio.foundation.entity.Foundation;

@Mapper(componentModel = "spring")
public interface FoundationMapper {
	@Mapping(source = "email", target = "email")
    Foundation foundationDTOToFoundation(FoundationDTO foundationDTO);
	
	@Mapping(source = "email", target = "email")
    FoundationDTO foundationToFoundationDTO(Foundation foundation);

}
