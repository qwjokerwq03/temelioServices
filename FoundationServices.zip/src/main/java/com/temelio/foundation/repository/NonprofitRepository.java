package com.temelio.foundation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.temelio.foundation.entity.Nonprofit;

@Repository
public interface NonprofitRepository extends JpaRepository<Nonprofit, Long> {

	Nonprofit findByEmail(String email);

	Nonprofit getByEmail(String email);

	List<Nonprofit> findAllByEmail(String email);
}
