package com.temelio.foundation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.temelio.foundation.entity.Foundation;

@Repository
public interface FoundationRepository extends JpaRepository<Foundation, Long> {

	void deleteByEmail(String email);

	Foundation getByEmail(String email);

	List<Foundation> findAllByEmail(String email);
}
