package com.temelio.foundation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.temelio.foundation.entity.EmailTemplate;

public interface EmailTemplateRepository extends JpaRepository<EmailTemplate, Long>{

	List<EmailTemplate> findAll();

}
