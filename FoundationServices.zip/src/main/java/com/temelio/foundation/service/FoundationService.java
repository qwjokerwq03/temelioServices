package com.temelio.foundation.service;

import java.util.List;
import com.temelio.foundation.dto.FoundationDTO;

public interface FoundationService {
    String createFoundation(FoundationDTO foundationDTO);

	List<FoundationDTO> getAllFoundations();

	void deleteFoundation(String email);

	int createAll(List<FoundationDTO> foundationDTOs);
}

