package com.temelio.foundation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.temelio.foundation.dto.NonprofitDTO;
import com.temelio.foundation.dto.mapper.NonprofitMapper;
import com.temelio.foundation.entity.Nonprofit;
import com.temelio.foundation.repository.EmailRepository;
import com.temelio.foundation.repository.NonprofitRepository;
import com.temelio.foundation.service.NonprofitService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NonprofitServiceImpl implements NonprofitService {
	
	@Autowired
    private NonprofitRepository nonprofitRepository;
	
	@Autowired
    private NonprofitMapper nonprofitMapper;
	
	@Autowired
	private EmailRepository emailRepository;

    @Override
    public String createNonprofit(NonprofitDTO nonprofitDTO) {
    	if(nonprofitRepository.findAllByEmail(nonprofitDTO.getEmail()).size() == 0) {
        Nonprofit nonprofit = nonprofitMapper.nonprofitDTOToNonprofit(nonprofitDTO);
        nonprofit = nonprofitRepository.save(nonprofit);
        return "CREATED";
    	}
    	return "ALREADY_EXISTS";
    }

    @Override
    public List<NonprofitDTO> getAllNonprofits() {
        return nonprofitRepository.findAll().stream()
                .map(nonprofitMapper::nonprofitToNonprofitDTO)
                .collect(Collectors.toList());
    }

	@Override
	public String getCount() {
		System.out.println("get count is called");
		return "ABC...";
	}

	@Override
	public void deleteNonprofit(String email) {
		// TODO Auto-generated method stub
		List<Nonprofit> nonprofits = nonprofitRepository.findAllByEmail(email);
		for(Nonprofit n : nonprofits) {
			emailRepository.deleteAll(emailRepository.findAllByToId(n.getId()));
		}
		nonprofitRepository.deleteAll(nonprofits);
		
	}

	@Override
	public int createNonprofitAll(List<NonprofitDTO> nonprofitDTOs) {
		// TODO Auto-generated method stub
		
		return nonprofitRepository.saveAll(nonprofitDTOs.stream()
				.map(nonprofitMapper::nonprofitDTOToNonprofit)
				.collect(Collectors.toList()))
				.size();
	}
}

