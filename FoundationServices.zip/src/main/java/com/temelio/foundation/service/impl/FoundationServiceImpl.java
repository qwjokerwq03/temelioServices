package com.temelio.foundation.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.temelio.foundation.dto.FoundationDTO;
import com.temelio.foundation.dto.mapper.FoundationMapper;
import com.temelio.foundation.entity.Foundation;
import com.temelio.foundation.repository.EmailRepository;
import com.temelio.foundation.repository.FoundationRepository;
import com.temelio.foundation.service.FoundationService;

@Service
public class FoundationServiceImpl implements FoundationService {
	

	@Autowired
    private FoundationRepository foundationRepository;
	
	@Autowired
    private FoundationMapper foundationMapper;
	
	@Autowired
	private EmailRepository emailRepository;

    @Override
    public String createFoundation(FoundationDTO foundationDTO) {
    	if(foundationRepository.findAllByEmail(foundationDTO.getEmail()).size() == 0) {
    		Foundation foundation = foundationMapper.foundationDTOToFoundation(foundationDTO);
    		foundation = foundationRepository.save(foundation);
    		return "CREATED";
    	}
        return "ALREADY_EXISTS";
    }

	@Override
	public List<FoundationDTO> getAllFoundations() {
		return foundationRepository.findAll().stream()
                .map(foundationMapper::foundationToFoundationDTO)
                .collect(Collectors.toList());
	}

	@Override
	public void deleteFoundation(String email) {
		// TODO Auto-generated method stub
		List<Foundation> foundation =foundationRepository.findAllByEmail(email);
		for(Foundation f : foundation) {
			emailRepository.deleteAll(emailRepository.findAllByFromId(f.getId()));
		}
		foundationRepository.deleteAll(foundation);
		
	}

	@Override
	public int createAll(List<FoundationDTO> foundationDTOs) {
		// TODO Auto-generated method stub
		return foundationRepository.saveAll(foundationDTOs.stream()
				.map(foundationMapper::foundationDTOToFoundation)
				.collect(Collectors.toList()))
				.size();
	}
}
