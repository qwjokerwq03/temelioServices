package com.temelio.foundation.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.temelio.foundation.dto.EmailDTO;
import com.temelio.foundation.dto.EmailTemplateDTO;
import com.temelio.foundation.dto.mapper.EmailMapper;
import com.temelio.foundation.dto.mapper.FoundationMapper;
import com.temelio.foundation.dto.mapper.NonprofitMapper;
import com.temelio.foundation.entity.Email;
import com.temelio.foundation.entity.EmailTemplate;
import com.temelio.foundation.repository.EmailRepository;
import com.temelio.foundation.repository.EmailTemplateRepository;
import com.temelio.foundation.repository.FoundationRepository;
import com.temelio.foundation.repository.NonprofitRepository;
import com.temelio.foundation.service.EmailService;

@Service
public class EmailServiceImpl implements EmailService{
	
	@Autowired
	private EmailRepository emailRepository;
	
	@Autowired
	private FoundationRepository foundationRepository;
	
	@Autowired
	private FoundationMapper foundationMapper;
	
	@Autowired
    private NonprofitRepository nonprofitRepository;
	
	@Autowired
    private NonprofitMapper nonprofitMapper;
	
	@Autowired
	private EmailMapper emailMapper;
	
	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	@Override
	public List<EmailDTO> getAllEmails() {
		// TODO Auto-generated method stub
		List<Email> emails = emailRepository.findAll();
		List<EmailDTO> emailsDTO = new ArrayList<>();
		for(Email email : emails) {
			EmailDTO emailDTO = emailMapper.emailToEmailDTO(email);
			emailDTO.setFoundationDTO(foundationMapper.foundationToFoundationDTO(foundationRepository.getById(email.getFromId())));
			emailDTO.setNonprofitDTO(nonprofitMapper.nonprofitToNonprofitDTO(nonprofitRepository.getById(email.getToId())));
			emailsDTO.add(emailDTO);
		}
		return emailsDTO;
	}

	@Override
	public void sendEmails(String from, List<String> tos) {
		List<Email> emails = new ArrayList<>();
		// TODO Auto-generated method stub
		for(String to : tos) {
			sendEmail(from,to);
			
			Email email= new Email();
			email.setDate(new Date());
			email.setFromId(foundationRepository.getByEmail(from).getId());
			email.setToId(nonprofitRepository.findByEmail(to).getId());
			emails.add(email);
		}
		emailRepository.saveAll(emails);
	}
	
	private void sendEmail(String from , String to) {
		System.out.println("The email as been sent to "+to+" from "+ from);
	}

	@Override
	public EmailTemplateDTO getTemplate() {
		// TODO Auto-generated method stub
		List<EmailTemplate> t = emailTemplateRepository.findAll();
		if(t.size() != 0) {
			return emailMapper.emailTemplateToEmailTemplateDTO(t.get(0));
		}
		EmailTemplate e =  new EmailTemplate();
		emailTemplateRepository.save(e);
		return emailMapper.emailTemplateToEmailTemplateDTO(e);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return (int)emailRepository.count();
	}

}
