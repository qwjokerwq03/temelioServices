package com.temelio.foundation.service;

import java.util.List;

import com.temelio.foundation.dto.EmailDTO;
import com.temelio.foundation.dto.EmailTemplateDTO;

public interface EmailService {
	
	List<EmailDTO> getAllEmails();
	
	void sendEmails(String from , List<String> to);

	EmailTemplateDTO getTemplate();

	int getCount();
}
