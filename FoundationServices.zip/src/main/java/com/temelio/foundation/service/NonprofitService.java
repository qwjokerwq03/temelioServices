package com.temelio.foundation.service;

import java.util.List;

import com.temelio.foundation.dto.NonprofitDTO;

public interface NonprofitService {
    String createNonprofit(NonprofitDTO nonprofitDTO);
    List<NonprofitDTO> getAllNonprofits();
    
    String getCount();
	void deleteNonprofit(String email);
	int createNonprofitAll(List<NonprofitDTO> nonprofitDTOs);
}

