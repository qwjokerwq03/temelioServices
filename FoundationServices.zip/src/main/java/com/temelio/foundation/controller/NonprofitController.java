package com.temelio.foundation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.temelio.foundation.dto.NonprofitDTO;
import com.temelio.foundation.service.NonprofitService;

import java.util.List;

@RestController
@RequestMapping("/nonprofits")
public class NonprofitController {

    private final NonprofitService nonprofitService;

    @Autowired
    public NonprofitController(NonprofitService nonprofitService) {
        this.nonprofitService = nonprofitService;
    }

    @PostMapping("/create")
    public String createNonprofit(@RequestBody NonprofitDTO nonprofitDTO) {
        return nonprofitService.createNonprofit(nonprofitDTO);
    }

    @GetMapping("/nonprofits")
    public List<NonprofitDTO> getAllNonprofits() {
        return nonprofitService.getAllNonprofits();
    }
    
    @GetMapping("/get-count")
    public String getCount() {
    	
		return nonprofitService.getCount();
    	
    }
    @DeleteMapping("/delete")
    public List<NonprofitDTO> deleteNonprofit(@RequestParam String email){
    	nonprofitService.deleteNonprofit(email);
    	return getAllNonprofits();
    }
    
    @PostMapping("/default-create")
    public int createNonprofitDefault(@RequestBody List<NonprofitDTO> nonprofitDTOs) {
        return nonprofitService.createNonprofitAll(nonprofitDTOs);
    }

}

