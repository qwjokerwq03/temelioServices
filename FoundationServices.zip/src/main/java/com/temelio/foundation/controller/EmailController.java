package com.temelio.foundation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.temelio.foundation.dto.EmailDTO;
import com.temelio.foundation.dto.EmailTemplateDTO;
import com.temelio.foundation.service.EmailService;

@RestController
@RequestMapping(path ={ "/email" })
public class EmailController {
	
	@Autowired
	private EmailService emailService;
	
	@GetMapping("/get-all")
	public List<EmailDTO> getAllEmails(){
		return emailService.getAllEmails();
	}
	
	@PostMapping("/send-emails")
	public void sendEmails(@RequestParam("from") String from, @RequestBody List<String> tos) {
		emailService.sendEmails(from, tos); 
	}
	
	@GetMapping("/get-template")
	public EmailTemplateDTO getTemplate() {
		return emailService.getTemplate();
	}
	
	@GetMapping("/get-count")
	public int getCount() {
		return emailService.getCount();
	}

}
