package com.temelio.foundation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.temelio.foundation.dto.FoundationDTO;
import com.temelio.foundation.service.FoundationService;

@RestController
@RequestMapping(path ={ "/foundations" })
public class FoundationController {

    private final FoundationService foundationService;

    @Autowired
    public FoundationController(FoundationService foundationService) {
        this.foundationService = foundationService;
    }

    @PostMapping("/create")
    public String createFoundation(@RequestBody FoundationDTO foundationDTO) {
        return foundationService.createFoundation(foundationDTO);
    }
    
    @GetMapping("/get-all")
    public List<FoundationDTO> getAllFoundations(){
    	return foundationService.getAllFoundations();
    }
    
    @DeleteMapping("/delete")
    public List<FoundationDTO> deleteFoundation(@RequestParam("email") String email) {
    	foundationService.deleteFoundation(email);
    	return getAllFoundations();
    }
    
    @PostMapping("/create-default")
    public int createDefaultFoundations(@RequestBody List<FoundationDTO> foundationDTOs) {
    	return foundationService.createAll(foundationDTOs);
    }
}

