package com.temelio.foundation.entity;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EmailTemplate {
	public static final String TEMPLATE_SUBJECT = "Donation Information";
    public static final String TEMPLATE_BODY =
        "Dear ${name},\n\n" +
        "We are pleased to inform you that a donation has been made to your organization.\n\n" +
        "Donor Information:\n" +
        "- Name: Ananomus\n" +
        "- Amount: ${amount}\n\n" +
        "We hope that this contribution will support your noble cause and help make a positive impact in the community.\n\n" +
        "Warm regards,\n\n" +
        "${foundationName}";
    
    public static String populateTemplate(Map<String, String> values , String populatedTemplate) {
//        String populatedTemplate = EmailTemplate.TEMPLATE_BODY;
        for (Map.Entry<String, String> entry : values.entrySet()) {
            String placeholder = "${" + entry.getKey() + "}";
            populatedTemplate = populatedTemplate.replace(placeholder, entry.getValue());
        }
        return populatedTemplate;
    }
    
    @Id
    private Long id = (long) 1;
    
    private String subject;
    
    public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}
	
	@Column(length = 1000) 
	private String body;
	
	public EmailTemplate() {
		this.subject = TEMPLATE_SUBJECT;
		this.body = TEMPLATE_BODY;
	}
	
	public String sendEmail(Map<String, String> values) {
		return "Subject:"+
				this.subject+"\n\n" +
				populateTemplate(values,this.body);
	}
}
